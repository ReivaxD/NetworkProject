package reso.common;

public interface InterfaceAttrListener {

	void attrChanged(Interface iface, String attr);
	
}
